$('#leao').myPlugin(); 
$('#girafa').myPlugin(); 