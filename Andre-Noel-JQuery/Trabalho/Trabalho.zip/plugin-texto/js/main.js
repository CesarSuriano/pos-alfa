// $('#texto').on('keyup', function(){
//     $('#texto-digitado').text($('#texto').myPlugin())
// })

function resultado() {
    $('#texto-digitado').html(($('#texto').myPlugin()))
}