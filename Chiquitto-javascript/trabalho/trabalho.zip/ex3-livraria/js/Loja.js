class Loja {
    constructor(nome, endereco) {
        this.nome = nome;
        this.endereco = endereco;
    }
}