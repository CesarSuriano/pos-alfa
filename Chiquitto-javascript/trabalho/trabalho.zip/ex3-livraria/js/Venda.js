class Venda {
    constructor(dataVenda, valorTotal) {
        this.dataVenda = dataVenda;
        this.valorTotal = valorTotal;
    }
}