class Livro {
    constructor(autor, numPaginas, titulo, valor) {
        this.autor = autor;
        this.numPaginas = numPaginas;
        this.titulo = titulo;
        this.valor = valor;
    }
}